This is a plugin for MuseScore 1.2, 2.x, 3.x and 4.x to import ABC notation. The plugin calls a webservice to achieve ABC to MusicXML conversion.

For more info see 

   - The official project page https://musescore.org/en/project/abc-import
   - ABC2XML webservice https://musescore.jeetee.net/abc/abc2xml.py

This branch concern the v4 compatible version of the plugin.
For older versions, use the v1-3 branch
